<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Create Lease - Lease App</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 30px; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #1e3a8a; }
        fieldset { border: 1px solid #d1d5db; border-radius: 6px; margin-bottom: 20px; padding: 15px 20px; }
        legend { font-weight: bold; color: #1d4ed8; padding: 0 8px; }
        label { display: block; margin-top: 10px; margin-bottom: 4px; font-size: 14px; color: #374151; }
        input[type=text], input[type=number], input[type=date], input[type=email], select, textarea {
            width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 14px;
        }
        .row { display: flex; gap: 15px; }
        .row > div { flex: 1; }
        .checkbox-group label { display: inline-flex; align-items: center; gap: 6px; font-weight: normal; margin-right: 15px; margin-top: 6px; }
        .checkbox-group input { width: auto; }
        .radio-group label { font-weight: normal; display: inline-block; margin-right: 20px; }
        .radio-group input { width: auto; margin-right: 6px; }
        button { width: 100%; padding: 12px; background: #2563eb; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; margin-top: 10px; }
        button:hover { background: #1d4ed8; }
        .error { color: red; text-align: center; }
        .conditional { display: none; margin-top: 10px; padding: 10px; background: #f9fafb; border-radius: 4px; }
    </style>
    <script>
        function toggleLeaseType() {
            var type = document.querySelector('input[name="leaseType"]:checked');
            document.getElementById('periodicFields').style.display = 'none';
            document.getElementById('fixedFields').style.display = 'none';
            if (type) {
                if (type.value === 'PERIODIC') document.getElementById('periodicFields').style.display = 'block';
                if (type.value === 'FIXED_TERM') document.getElementById('fixedFields').style.display = 'block';
            }
        }
        function toggleDeposit() {
            var checked = document.getElementById('securityDepositRequired').checked;
            document.getElementById('depositFields').style.display = checked ? 'block' : 'none';
        }
        function togglePaymentOther() {
            var val = document.getElementById('paymentMethod').value;
            document.getElementById('paymentOtherField').style.display = (val === 'OTHER') ? 'block' : 'none';
        }
    </script>
</head>
<body>
<div class="container">
    <h2>Create New Lease</h2>

    <% if (request.getAttribute("error") != null) { %>
        <p class="error"><%= request.getAttribute("error") %></p>
    <% } %>

    <form action="create-lease" method="post">

        <!-- Section 1 (partial) - Landlord -->
        <fieldset>
            <legend>Section 1 &mdash; Landlord</legend>
            <label>Landlord Name</label>
            <input type="text" name="landlordName" required>

            <label>Street Address</label>
            <input type="text" name="landlordStreetAddress" required>

            <label>Mailing Address (if different)</label>
            <input type="text" name="landlordMailingAddress">

            <div class="row">
                <div>
                    <label>Apartment</label>
                    <input type="text" name="landlordApartment">
                </div>
                <div>
                    <label>City / Town</label>
                    <input type="text" name="landlordCity" required>
                </div>
                <div>
                    <label>Postal Code</label>
                    <input type="text" name="landlordPostalCode" required>
                </div>
            </div>

            <div class="row">
                <div>
                    <label>Phone (home)</label>
                    <input type="text" name="landlordPhoneHome">
                </div>
                <div>
                    <label>Phone (business/other)</label>
                    <input type="text" name="landlordPhoneBusiness">
                </div>
            </div>
        </fieldset>

        <!-- Section 3 - Premises -->
        <fieldset>
            <legend>Section 3 &mdash; Premises</legend>
            <label>Street Address of Rental Property</label>
            <input type="text" name="premisesStreetAddress" required>

            <div class="row">
                <div>
                    <label>Apartment</label>
                    <input type="text" name="premisesApartment">
                </div>
                <div>
                    <label>City / Town</label>
                    <input type="text" name="premisesCity" required>
                </div>
                <div>
                    <label>Postal Code</label>
                    <input type="text" name="premisesPostalCode" required>
                </div>
            </div>

            <label>Type of Property</label>
            <input type="text" name="propertyType" placeholder="e.g. Detached, Apartment" required>

            <div class="row">
                <div>
                    <label>Tenant's Mailing P.O. Box (if applicable)</label>
                    <input type="text" name="tenantMailingPobox">
                </div>
                <div>
                    <label>Postal Code</label>
                    <input type="text" name="tenantMailingPostalCode">
                </div>
            </div>

            <div class="row">
                <div>
                    <label>Tenant's Phone (home)</label>
                    <input type="text" name="tenantPhoneHome">
                </div>
                <div>
                    <label>Tenant's Phone (business/other)</label>
                    <input type="text" name="tenantPhoneBusiness">
                </div>
            </div>
        </fieldset>

        <!-- Section 9 - Landlord's email for service -->
        <fieldset>
            <legend>Section 9 &mdash; Email for Service of Documents (Tenant to Landlord)</legend>
            <label>Landlord's Email Address</label>
            <input type="email" name="landlordServiceEmail">
        </fieldset>

        <!-- Section 11A/11B - Lease type -->
        <fieldset>
            <legend>Section 11 &mdash; Lease Type</legend>
            <div class="radio-group">
                <label><input type="radio" name="leaseType" value="PERIODIC" onclick="toggleLeaseType()" required> Periodic Lease (11A)</label>
                <label><input type="radio" name="leaseType" value="FIXED_TERM" onclick="toggleLeaseType()"> Fixed-Term Lease (11B)</label>
            </div>

            <div id="periodicFields" class="conditional">
                <label>Tenancy Start Date</label>
                <input type="date" name="periodicStartDate">
                <label>Term</label>
                <select name="periodicTerm">
                    <option value="YEAR_TO_YEAR">Year-to-Year</option>
                    <option value="MONTH_TO_MONTH">Month-to-Month</option>
                    <option value="WEEK_TO_WEEK">Week-to-Week</option>
                </select>
            </div>

            <div id="fixedFields" class="conditional">
                <label>Start Date</label>
                <input type="date" name="fixedStartDate">
                <label>End Date</label>
                <input type="date" name="fixedEndDate">
            </div>
        </fieldset>

        <!-- Section 13 - Rent -->
        <fieldset>
            <legend>Section 13 &mdash; Rent</legend>
            <div class="row">
                <div>
                    <label>Rent Amount ($)</label>
                    <input type="number" step="0.01" name="rentAmount" required>
                </div>
                <div>
                    <label>Frequency</label>
                    <select name="rentFrequency">
                        <option value="MONTH">Per Month</option>
                        <option value="WEEK">Per Week</option>
                    </select>
                </div>
            </div>

            <label>Payment Method</label>
            <select name="paymentMethod" id="paymentMethod" onchange="togglePaymentOther()">
                <option value="CASH">Cash</option>
                <option value="AUTO_WITHDRAWAL">Pre-authorized Automatic Withdrawal</option>
                <option value="POST_DATED_CHEQUES">Post-dated Cheques</option>
                <option value="CHEQUE">Cheque</option>
                <option value="OTHER">Other</option>
            </select>
            <div id="paymentOtherField" class="conditional">
                <label>Specify Other Payment Method</label>
                <input type="text" name="paymentMethodOther">
            </div>

            <div class="row">
                <div>
                    <label>Rent Due Day (day of month/week)</label>
                    <input type="number" name="rentDueDay" min="1" max="31">
                </div>
                <div>
                    <label>Rent Payable To</label>
                    <input type="text" name="rentPayableTo">
                </div>
            </div>
        </fieldset>

        <!-- Section 16 (top) - Rent includes -->
        <fieldset>
            <legend>Section 16 &mdash; Rent Includes</legend>

            <label>Appliances</label>
            <div class="checkbox-group">
                <label><input type="checkbox" name="inclStove"> Stove</label>
                <label><input type="checkbox" name="inclFridge"> Fridge</label>
                <label><input type="checkbox" name="inclWasherDryer"> Washer &amp; Dryer</label>
                <label><input type="checkbox" name="inclDishwasher"> Dishwasher</label>
                <label><input type="checkbox" name="inclFurniture"> Furniture</label>
            </div>

            <label>Utilities</label>
            <div class="checkbox-group">
                <label><input type="checkbox" name="inclCoinLaundry"> Washer/Dryer (coin operated)</label>
                <label><input type="checkbox" name="inclCable"> Cable Service</label>
                <label><input type="checkbox" name="inclHeat"> Heat</label>
                <label><input type="checkbox" name="inclWater"> Water</label>
                <label><input type="checkbox" name="inclHotWater"> Hot Water</label>
                <label><input type="checkbox" name="inclElectricity"> Electricity</label>
                <label><input type="checkbox" name="inclRecyclingFacilities"> Recycling Facilities</label>
            </div>
            <div class="row">
                <div>
                    <label># of Parking Spaces</label>
                    <input type="number" name="inclParkingSpaces" min="0">
                </div>
                <div>
                    <label>Space #</label>
                    <input type="text" name="inclParkingSpaceNumber">
                </div>
            </div>

            <label>Other Included</label>
            <div class="checkbox-group">
                <label><input type="checkbox" name="inclLawnCare"> Lawn Care</label>
                <label><input type="checkbox" name="inclSnowRemoval"> Snow Removal</label>
                <label><input type="checkbox" name="inclGarbageRemoval"> Garbage Removal</label>
            </div>
            <label>Other (specify)</label>
            <input type="text" name="inclOtherCustom">
        </fieldset>

        <!-- Section 16 (bottom) - Tenant responsibilities -->
        <fieldset>
            <legend>Section 16 &mdash; Tenant is Responsible For</legend>
            <div class="checkbox-group">
                <label><input type="checkbox" name="respLawnCare"> Lawn Care</label>
                <label><input type="checkbox" name="respLatePayment"> Late Payment Charges</label>
                <label><input type="checkbox" name="respSnowRemoval"> Snow Removal</label>
                <label><input type="checkbox" name="respGarbageRemoval"> Garbage Removal</label>
                <label><input type="checkbox" name="respTenantInsurance"> Tenant Insurance</label>
                <label><input type="checkbox" name="respSeparationRecyclables"> Separation of Recyclables</label>
            </div>

            <div class="row">
                <div>
                    <label>Returned Cheque Charge Limit ($)</label>
                    <input type="number" step="0.01" name="respReturnedChequeLimit">
                </div>
                <div>
                    <label>Lockout Charge Limit ($)</label>
                    <input type="number" step="0.01" name="respLockoutChargeLimit">
                </div>
            </div>

            <div class="row">
                <div>
                    <label>Parking Fee ($/month)</label>
                    <input type="number" step="0.01" name="respParkingFee">
                </div>
                <div>
                    <label># of Parking Spaces</label>
                    <input type="number" name="respParkingSpaces" min="0">
                </div>
            </div>

            <label>Sublet Expense Limit ($) &mdash; not to exceed $75</label>
            <input type="number" step="0.01" name="respSubletExpenseLimit" max="75" value="75">
        </fieldset>

        <!-- Section 17 - Additional obligations -->
        <fieldset>
            <legend>Section 17 &mdash; Additional Obligations</legend>
            <textarea name="additionalObligations" rows="3" placeholder="Any additional terms..."></textarea>
        </fieldset>

        <!-- Section 18 - Security deposit -->
        <fieldset>
            <legend>Section 18 &mdash; Security Deposit</legend>
            <label><input type="checkbox" id="securityDepositRequired" name="securityDepositRequired" onclick="toggleDeposit()"> Security deposit required</label>

            <div id="depositFields" class="conditional">
                <label>Deposit Amount ($) &mdash; not to exceed 1/2 month's rent</label>
                <input type="number" step="0.01" name="securityDepositAmount">
                <label>Financial Institution / Branch</label>
                <input type="text" name="securityDepositInstitution">
            </div>
        </fieldset>

        <!-- Section 19 - Inspection -->
        <fieldset>
            <legend>Section 19 &mdash; Inspection</legend>
            <label><input type="checkbox" name="inspectionReportAttached"> Inspection report is attached to the lease</label>
        </fieldset>

        <button type="submit">Save and Continue to Add Tenants</button>
    </form>
</div>
</body>
</html>
