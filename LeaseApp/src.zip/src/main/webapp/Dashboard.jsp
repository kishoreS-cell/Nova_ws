<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("Login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Lease App</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 40px; }
        .card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); max-width: 500px; margin: 0 auto; }
        a { color: #2563eb; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Welcome, <%= session.getAttribute("userName") %>!</h2>
        <p>Homeowner Dashboard - lease creation form will go here next.</p>
        <a href="create-lease"><button>Create New Lease</button></a>
        <a href="Logout">Logout</a>
    </div>
</body>
</html>
